from .latte import Latte, Latte_XL_2, Latte_XL_2x2
