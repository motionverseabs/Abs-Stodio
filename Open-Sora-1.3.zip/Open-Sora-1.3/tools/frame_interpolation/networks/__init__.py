from .amt_g import Model
